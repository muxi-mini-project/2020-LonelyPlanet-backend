package model

import (
	"reflect"
	"testing"
)

func TestGetUserInfoFormOne(t *testing.T) {
	type args struct {
		sid string
		pwd string
	}
	tests := []struct {
		name    string
		args    args
		want    SuInfo
		wantErr bool
	}{
		{
			name: "1",
			args: args{
				sid: "2019214300",
				pwd: "", //密码
			},
			want: SuInfo{
				Errcode: "0",
				Errmsg:  "ok",
				User: struct {
					DeptID       string `json:"deptId"`
					DeptName     string `json:"deptName"`
					ID           string `json:"id"`
					Mobile       string `json:"mobile"`
					Name         string `json:"name"`
					SchoolEmail  string `json:"schoolEmail"`
					Status       int    `json:"status"`
					UserFace     string `json:"userFace"`
					Username     string `json:"username"`
					Usernumber   string `json:"usernumber"`
					Usertype     string `json:"usertype"`
					UsertypeName string `json:"usertypeName"`
					Xb           string `json:"xb"`
				}{
					Status:     1,
					Usernumber: "2019214300",
					Xb:         "1",
				},
			},
			wantErr: false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := GetUserInfoFormOne(tt.args.sid, tt.args.pwd)
			if (err != nil) != tt.wantErr {
				t.Errorf("GetUserInfoFormOne() error = %v, wantErr %v", err, tt.wantErr)
				return
			}
			if !reflect.DeepEqual(got.User.Usernumber, tt.want.User.Usernumber) && !reflect.DeepEqual(got.User.Xb, tt.want.User.Xb) {
				t.Errorf("GetUserInfoFormOne() got = %v, want %v", got, tt.want)
			}
		})
	}
}
