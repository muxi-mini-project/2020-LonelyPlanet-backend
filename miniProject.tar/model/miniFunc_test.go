package model

import (
	"reflect"
	"strconv"
	"testing"
	"time"
)

func TestBinStr2Dec(t *testing.T) {
	type args struct {
		str string
	}
	tests := []struct {
		name string
		args args
		want int
	}{
		{
			name: "1",
			args: args{"11111111"},
			want: 255,
		},
		{
			name: "2",
			args: args{"10000001"},
			want: 129,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got, _ := BinStr2Dec(tt.args.str); got != tt.want {
				t.Errorf("BinStr2Dec() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestChangeString(t *testing.T) {
	type args struct {
		str  string
		from int
		end  int
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "1",
			args: args{
				str:  "123456789",
				from: 1,
				end:  3,
			},
			want: "123",
		},
		{
			name: "1",
			args: args{
				str:  "123456789",
				from: 1,
				end:  4,
			},
			want: "1234",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := ChangeString(tt.args.str, tt.args.from, tt.args.end); got != tt.want {
				t.Errorf("ChangeString() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestConvertStringToIntSlice(t *testing.T) {
	type args struct {
		str string
	}
	tests := []struct {
		name string
		args args
		want []int
	}{
		{
			name: "1",
			args: args{
				str: "123",
			},
			want: []int{1, 2, 3},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got, _ := ConvertStringToIntSlice(tt.args.str); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("ConvertStringToIntSlice() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestDec2BinStr(t *testing.T) {
	type args struct {
		num int
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "1",
			args: args{129},
			want: "10000001",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := Dec2BinStr(tt.args.num); got != tt.want {
				t.Errorf("Dec2BinStr() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestNowTimeStampStr(t *testing.T) {
	tests := []struct {
		name string
		want string
	}{
		{
			name: "1",
			want: strconv.FormatInt(time.Now().Unix(), 10),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := NowTimeStampStr(); got != tt.want {
				t.Errorf("NowTimeStampStr() = %v, want %v", got, tt.want)
			}
		})
	}
}
