package model

import "testing"

func Test_dateImprove(t *testing.T) {
	type args struct {
		date string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "1",
			args: args{
				date: "10010101",
			},
			want: "周五 周三 周一",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := dateImprove(tt.args.date); got != tt.want {
				t.Errorf("dateImprove() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_mainTypeImprove(t *testing.T) {
	type args struct {
		type1 int
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "1",
			args: args{
				type1: 1,
			},
			want: "学习",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := mainTypeImprove(tt.args.type1); got != tt.want {
				t.Errorf("mainTypeImprove() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_placeImprove(t *testing.T) {
	type args struct {
		place int
		type1 int
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "1",
			args: args{
				place: 1,
				type1: 1,
			},
			want: "教学楼",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := placeImprove(tt.args.place, tt.args.type1); got != tt.want {
				t.Errorf("placeImprove() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_tagImprove(t *testing.T) {
	type args struct {
		tag   int
		type1 int
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "1",
			args: args{
				tag:   1,
				type1: 1,
			},
			want: "自习",
		},
		{
			name: "2",
			args: args{
				tag:   4,
				type1: 0,
			},
			want: "",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tagImprove(tt.args.tag, tt.args.type1); got != tt.want {
				t.Errorf("tagImprove() = %v, want %v", got, tt.want)
			}
		})
	}
}

func Test_timestamp2json(t *testing.T) {
	type args struct {
		str string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			name: "1",
			args: args{
				str: "1581159691",
			},
			want: "02-08 19:01",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := timestamp2json(tt.args.str); got != tt.want {
				t.Errorf("timestamp2json() = %v, want %v", got, tt.want)
			}
		})
	}
}
